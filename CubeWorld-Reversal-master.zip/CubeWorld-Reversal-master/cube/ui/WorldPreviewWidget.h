// WorldPreviewWidget (cube) — reconstructed declarations.
#ifndef CUBE_UI_WORLDPREVIEWWIDGET_H
#define CUBE_UI_WORLDPREVIEWWIDGET_H
#include "../include/cube_types.h"

void cube::WorldPreviewWidget::ctor_0(undefined4 param_1,undefined4 param_2,undefined4 param_3);

#endif
